<!DOCTYPE html>
<html>
<head>
</head>
<body>
<?php
   $db = new SQLite3('test.db');
?>

<?php

   $sql =<<<EOF
      CREATE TABLE REGISTERED
      ( NAME           TEXT,
      ADDRESS        TEXT, 
      EMAIL            TEXT,
      MOBILE        INT,
      ACCOUNT         TEXT,
      PASSWORD         TEXT);
EOF;
$ret = $db->exec($sql);

?>
<?php

   $sql =<<<EOF
      CREATE TABLE BALANCE
      ( ACCOUNT           TEXT,
      PASSWORD        TEXT, 
      AMOUNT            INT);
EOF;
$ret = $db->exec($sql);
$sql =<<<EOF
   CREATE TABLE ADMIN
    (USERNAME TEXT,
    PASSWORD TEXT);
EOF;
$ret = $db->exec($sql);
?>



<?php
   $sql = "SELECT * from REGISTERED";
$flag1 = 0;
$ret = $db->query($sql);
while($row = $ret->fetchArray() ) {
    if($row['EMAIL'] == $_POST["uemail"]) {
        echo "This email is already registered\n";
        $flag1 = 1;
    }
}

$sql =<<<EOF
   SELECT * from BALANCE;
EOF;
$ret = $db->query($sql);
while($row = $ret->fetchArray() ) {
    if($row['ACCOUNT'] == $_POST["uacnumber"] && $row['PASSWORD'] != $_POST["upassword"]) {
        echo "Invalid Account/Password\n";
        $flag1 = 1;
    }
    if($row['ACCOUNT'] == $_POST["uacnumber"] && $row['PASSWORD'] == $_POST["upassword"] && $row['AMOUNT'] < 1000) {
        echo "Insufficient Balance\n";
        $flag1 = 1;
    }
   if($row['ACCOUNT'] == $_POST["uacnumber"] && $row['PASSWORD'] == $_POST["upassword"] && $row['AMOUNT'] >= 1000 && $flag1 == 0) {
        $new = $row['AMOUNT'] - 1000;
        $x = $_POST["uacnumber"];
        $sql ="UPDATE BALANCE SET AMOUNT='$new' where ACCOUNT='$x'";
        $db->query($sql);
    }
}
if($flag1 == 0) {
    $user = $_POST["uname"];
    $address = $_POST["uaddress"];
    $mail = $_POST["uemail"];
    $mobile = $_POST["umobile"];
    $account = $_POST["uacnumber"];
    $password = $_POST["upassword"];
    
    $sql =<<<EOF
    INSERT INTO REGISTERED (NAME, ADDRESS, EMAIL , MOBILE  , ACCOUNT,PASSWORD)
    VALUES ('$user','$address','$mail', '$mobile', '$account', '$password');
EOF;
    $ret = $db->exec($sql);
    echo "Registration Successful\n";
}

$db->close();
?>
</body>
</html>