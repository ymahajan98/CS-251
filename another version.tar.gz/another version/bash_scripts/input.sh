#!/bin/bash
read x y
echo $(( $x**$y ))

#alternative way for evaluating expressions

echo $[ $x**$y ]

