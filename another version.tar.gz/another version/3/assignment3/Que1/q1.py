#!/usr/bin/python
import string
import math
import sys
def chardigit(letter):
    if ord(letter) <= 91 and ord(letter)>=65:
        return ord(letter) - 55
    else:
        return ord(letter)-48
invalid=0
num=sys.argv[1]
b=(sys.argv[2])
#read num
#read b
b=b.lstrip('0')


if b.isdigit():
	pass
else:
	print ("Invalid Input")
	quit()

b=eval(b)

flag=0
if num[0]=='-':
    flag=1
    num=num.lstrip('-')

for i in num:
    if (i.isupper() or i.isdigit() or i==".") and ((chardigit(i)<b and chardigit(i)>=0) or i=="."):
        continue
    else:
        invalid=invalid+1

num=num.lstrip('0')
if num==".":
    invalid+=1

if '.' in num:
    parts=num.split(".")
    if len(parts)>2:
        invalid=invalid+1
    idig=len(parts[0])
    fdig=len(parts[1])
else:
    idig=len(num)

nondec=0
dec=0

if invalid==0:
    if idig>0:
        for i in range(idig-1, -1, -1):
            nondec=nondec+chardigit(num[i])*math.pow(b, idig-i-1)
    else:
        nondec=0

    if '.' in num:
        for i in range(0, fdig):
            dec=dec+chardigit(parts[1][i])*(b**(-i-1))
        req=str(round(dec, 6)).split(".")

    if flag==0:
        if '.' in num:
            print ("Nd= %d.%s" %(nondec, req[1]))
        else:
            print ("Nd=%d" %nondec)

    if flag==1:
        if '.' in num:
            print ("Nd= -%d.%s" %(nondec, req[1]))
        else:
            print ("Nd=-%d" %nondec)

else:
    print ("Invalid Input")







