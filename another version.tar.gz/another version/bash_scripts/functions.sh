#!/bin/bash

function gcd {
    echo $(( $1+$2 ))
}

gcd 8100 232
