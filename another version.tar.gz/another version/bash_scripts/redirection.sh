#!/bin/bash

ls -l > new.txt
# > is used to write into a file

grep da * 2> greperror.txt

# 1 represents stdout 2 represents stderr
