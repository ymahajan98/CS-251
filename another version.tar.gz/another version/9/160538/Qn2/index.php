<!DOCTYPE html>
<html>
<head>
  <title>Form Validation</title>
  <script>
    // javascript for form validation
    function validate() {
      var name = document.forms["createUser"]["uname"].value;
      var address = document.forms["createUser"]["uaddress"].value;
      var email = document.forms["createUser"]["uemail"].value;
      var mobile = document.forms["createUser"]["umobile"].value;
      var account = document.forms["createUser"]["uacnumber"].value;
      var password = document.forms["createUser"]["upassword"].value;

      var regexName = /^[a-zA-Z ]*$/;
      var regexPassword = /^\w+$/;
      var regexEmail = /\b[a-zA-Z]+@[a-zA-Z0-9.-]+\.com\b/;

      if(name == "" || name.length > 20 || !regexName.test(name)) {
        alert("Invalid Name");
        return false;
      }
      if(address.length > 100 || address == "") {
        alert("Invalid Address");
        return false;
      }
      if(email == "" || !regexEmail.test(email)) {
        alert("Invalid Email");
        return false;
      }
      if(isNaN(mobile) || mobile.length != 10) {
        alert("Invalid Mobile Number")
        return false;
      }
      if(isNaN(account) || account.length != 5) {
        alert("Invalid Bank Account Number");
        return false;
      }
      if(password.length > 20 || password == "" || !regexPassword.test(password)) {
        alert("Invalid Password");
        return false;
      }
      
      // document.getElementById("result").innerHTML = name;
    }
  </script>

</head> 

<body>
<?php
// creating registration table
   class MyDB extends SQLite3 {
      function __construct() {
         $this->open('test.db');
      }
   }
   $db = new MyDB();

   $sql =<<<EOF
      CREATE TABLE REGISTERED
      ( NAME           TEXT,
      ADDRESS        TEXT, 
      EMAIL            TEXT,
      MOBILE        INT,
      ACCOUNT         TEXT,
      PASSWORD         TEXT);
EOF;
$ret = $db->exec($sql);

   $db->close();
?>
<?php
// creating amount table
   class MyDB extends SQLite3 {
      function __construct() {
         $this->open('test.db');
      }
   }
   $db = new MyDB();

   $sql =<<<EOF
      CREATE TABLE BALANCE
      ( ACCOUNT           TEXT,
      PASSWORD        TEXT, 
      AMOUNT            INT);
EOF;
$ret = $db->exec($sql);
$sql =<<<EOF
   CREATE TABLE ADMIN
    (USERNAME TEXT,
    PASSWORD TEXT);
EOF;
$ret = $db->exec($sql);
   $db->close();
?>

  <div>
    <h1>Registration Page</h1>
    <!-- <form name="createUser" onsubmit="return validate()"
     method="post" action="/checker.php">  -->
     <form name="createUser" onsubmit="return validate()" method="post" action="/checker.php">
      Name: <br/> <input type="text" name="uname"> <br/>
      Address: <br/> <input type="text" name="uaddress"> <br/>
      Email: <br/> <input type="text" name="uemail"> <br/>
      Mobile Number: <br/> <input type="text" name="umobile"> <br/>
      Bank Account Number: <br/> <input type="text" name="uacnumber"> <br/>
      Bank Password: <br/> <input type="password" name="upassword"> </br>
      <p id="result"> </p>

      <input type="submit" value="submit">
    </form>
    <br/>
    <br/>
    <a href="/admin.html">Admin Login</a>
  </div>
</body>
</html>