import numpy as np
import csv
import matplotlib.pyplot as plt
from numpy.linalg import inv


n_train = 10000
n_test = 1000

rows = []


# STEP: 1

## reading the file
filename = "train.csv"
with open(filename,'r') as trainfile:
    trainreader = csv.reader(trainfile)
    fields = trainreader.next()

    for row in trainreader:
        rows.append(row)


X_train = np.zeros( (n_train,1), dtype=np.float64 )
Y_train = np.zeros( (n_train,1), dtype=np.float64 )

## storing in X,Y train
for i in range(len(rows)):
    X_train[i] = float(rows[i][0])
    Y_train[i] = float(rows[i][1])

## inserting a new column into X_train
dummy_matrix = np.ones ( (n_train,1), dtype = int )
X_train = np.hstack( (dummy_matrix,X_train) )


# STEP: 2

w = np.random.random( (2,1) )


# STEP: 3

plt.plot(X_train[:,1], Y_train, 'ro' )

X_new = np.transpose(X_train)
wX_new = np.transpose((np.matmul(w.T, X_new))) # w.T = transpose
## wX_train is an 1 x n matrix

#plt.plot( X_train[:,1], wX_new , 'bo' )
plt.plot( wX_new )


# STEP: 4

W_direct = np.matmul( np.matmul( inv( np.matmul(np.transpose(X_train),X_train) ), np.transpose(X_train)), Y_train )

# plt.plot(X_train[:,1], np.matmul(W_direct.T,X_new).T )

#plt.show()


# STEP: 5

# w is 2 x 1 dimensional vector

epoch = 0.00000001

for i in range(1,3 ):
    for j in range(0,n_train):
        x = X_train.item(j,1)
        y = Y_train.item(j)

        X_new = np.ones( (2,1) )
	X_new[1] = x

	factor = epoch * ( np.matmul( np.transpose(w), X_new ) - y )

	X_new = factor * X_new

	## update step
        w = w - X_new

	if (j % 100 == 0):
		plt.plot( X_train[:,1], np.matmul(w.T,X_train.T).T  )


# STEP: 6

X_new = np.transpose(X_train)
wX_new = np.transpose((np.matmul(np.transpose(w), X_new)))
plt.plot( X_train[:,1],wX_new, 'yo' ) ## printing with new value of w
plt.show()


# STEP: 7

## vector to store intermediate values from csv file
trainrows = []

filename = "test.csv"
with open(filename,'r') as trainfile:
    trainreader = csv.reader(trainfile)
    fields = trainreader.next()

    for row in trainreader:
        trainrows.append(row)

n_test = len(trainrows)

X_test = np.ones ( (n_test,2), dtype=np.float64 )
Y_test = np.zeros( (n_test,1), dtype=np.float64 )

for i in range(n_test):
    X_test[i][1] = float(trainrows[i][0])
    Y_test[i]    = float(trainrows[i][1])

y_pred1 = np.matmul(X_test,w)
y_pred2 = np.matmul(X_test,W_direct)

rms1 = 0.0
rms2 = 0.0

for i in range(n_test):
    rms1 = rms1 + ( (y_pred1[i] - Y_test[i])**2 )
    rms2 = rms2 + ( (y_pred2[i] - Y_test[i])**2 )
rms1 = (rms1 / n_test) ** 0.5
rms2 = (rms2 / n_test) ** 0.5

print "rms error in ypred1 is %0.13f" %(rms1)
print "rms error in ypred2 is %0.13f" %(rms2)
