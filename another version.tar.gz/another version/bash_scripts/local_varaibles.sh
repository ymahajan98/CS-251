#!/bin/bash

Hello=raman
function hello {

	local Hello=World
	echo $Hello
}

echo $Hello

hello

