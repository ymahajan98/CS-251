#!/bin/bash

declare -A digitmap #associative map declared

# stores answer for single digit number

digitmap[0]="zero"
digitmap[1]="one"
digitmap[2]="two"
digitmap[3]="three"
digitmap[4]="four"
digitmap[5]="five"
digitmap[6]="six"
digitmap[7]="seven"
digitmap[8]="eight"
digitmap[9]="nine"
digitmap[10]="ten"
digitmap[11]="eleven"
digitmap[12]="twelve"
digitmap[13]="thirteen"
digitmap[14]="fourteen"
digitmap[15]="fifteen"
digitmap[16]="sixteen"
digitmap[17]="seventeen"
digitmap[18]="eighteen"
digitmap[19]="nineteen"
digitmap[20]="twenty"
digitmap[30]="thirty"
digitmap[40]="forty"
digitmap[50]="fifty"
digitmap[60]="sixty"
digitmap[70]="seventy"
digitmap[80]="eighty"
digitmap[90]="ninety"

answer=""
# to store the final result

#function declarations
unit() {
    answer+="${digitmap[$1]} "

}

ten() {
    if [ $1 -lt 20 ]
    then
        if [ $1 -ne 0 ]; then
            answer+="${digitmap[$1]} "
        fi
    else
        t=$(( $1 / 10 ))
        t=$(( $t * 10 ))
        u=$(( $1 - $t ))

        answer+="${digitmap[$t]} "

        if [ $u -ne 0 ]; then
            unit $u
        fi
    fi

}

hundred() {
    local a=$(( $1 / 100 ))

    if [ $a -ge 1 ]
    then
        unit $a
        answer+="hundred "
    fi
    local a=$(( $1 - ( $a * 100 ) ))
    ten $a
}

thousand() {
    local a=$(( $1 / 1000 ))

    if [ $a -ge 10 ]
    then
        ten $a
        answer+="thousand "
    elif [ $a -ge 1 ]
    then
        unit $a
        answer+="thousand "
    fi


    local a=$(( $1 - ( $a * 1000 ) ))
    hundred $a
}

lakh() {
    local a=$(( $1 / 100000 ))

    if  [ $a -ge 10 ]
    then
        ten $a
        answer+="lakh "
    elif [ $a -ge 1 ]
    then
        unit $a
        answer+="lakh "
    fi



    local a=$(( $1 - ( $a * 100000 ) ))
    thousand $a

}
crore() {
    local a=$(( $1 / 10000000 ))

    if [ $a -ge 1000 ]
    then
        thousand $a
    elif [ $a -ge 100 ]
    then
        hundred $a
    elif [ $a -ge 10 ]
    then
        ten $a
    else
        unit $a
    fi

    answer+="crore "


    local a=$(( $1 - ( $a * 10000000 ) ))

    lakh $a
}

regex='^[0-9]+$'
# 1 or more occurence of a digit

number=$1

if  [[ $number =~ $regex ]]
then

    #base case as in later code trailing zero would be removed
    if [ $number -eq 0 ]
    then
        echo zero
        exit 0
    fi

    number=`echo $number | sed -e 's/^[0]*//'`
    #removing trailing zeros
    #-e means that next argument is editing command
    # s = substitute ^[0]* = leading zeros,


    #out of bounds
    if [ $number -gt 99999999999 ]
    then
        echo invalid input
        exit -1
    fi

    # all function work recursively to generate the result
    if [ $number -ge 10000000 ]
    then
        crore $number
    elif [ $number -ge 100000 ]
    then
        lakh $number
    elif [ $number -ge 1000 ]
    then
        thousand $number
    elif [ $number -ge 100 ]
    then
        hundred $number
    elif [ $number -ge 10 ]
    then
        ten $number
    else
        unit $number
    fi

    echo $answer

else
    echo invalid input
fi
