<!DOCTYPE html>
<html>
<head>
</head>
<body>
<?php
   $db = new SQLite3('test.db');
?>

<?php

   $sql =<<<EOF
      CREATE TABLE REGISTERED
      ( NAME           TEXT,
      ADDRESS        TEXT, 
      EMAIL            TEXT,
      MOBILE        INT,
      ACCOUNT         TEXT,
      PASSWORD         TEXT);
EOF;
$ret = $db->exec($sql);

?>
<?php

   $sql =<<<EOF
      CREATE TABLE BALANCE
      ( ACCOUNT           TEXT,
      PASSWORD        TEXT, 
      AMOUNT            INT);
EOF;
$ret = $db->exec($sql);
$sql =<<<EOF
   CREATE TABLE ADMIN
    (USERNAME TEXT,
    PASSWORD TEXT);
EOF;
$ret = $db->exec($sql);
?>



<?php
   $sql = "SELECT * from REGISTERED";
$flag1 = 0;
$ret = $db->query($sql);
while($row = $ret->fetchArray() ) {
    if($row['EMAIL'] == $_POST["uemail"]) {
        echo "This email is already registered\n";
        $flag1 = 1;
    }
}

$sql =<<<EOF
   SELECT * from BALANCE;
EOF;
$ret = $db->query($sql);
while($row = $ret->fetchArray() ) {
    if($row['ACCOUNT'] == $_POST["uacnumber"] && $row['PASSWORD'] != $_POST["upassword"]) {
        echo "Invalid Account/Password\n";
        $flag1 = 1;
    }
    if($row['ACCOUNT'] == $_POST["uacnumber"] && $row['PASSWORD'] == $_POST["upassword"] && $row['AMOUNT'] < 1000) {
        echo "Insufficient Balance\n";
        $flag1 = 1;
    }
   if($row['ACCOUNT'] == $_POST["uacnumber"] && $row['PASSWORD'] == $_POST["upassword"] && $row['AMOUNT'] >= 1000 && $flag1 == 0) {
        $new = $row['AMOUNT'] - 1000;
        $x = $_POST["uacnumber"];
        $sql ="DELETE from BALANCE where ACCOUNT='$x'";
        $db->exec($sql);
        $y = $row['PASSWORD'];
        $sql =<<<EOF
        INSERT INTO BALANCE (ACCOUNT,PASSWORD,AMOUNT)
      VALUES ('$x', '$y', '$new' );
EOF;
        $ret = $db->query($sql);
    }
}
echo "ksknx";

// if($flag1 == 0) {
//     $sql =<<<EOF
//     INSERT INTO BALANCE (NAME, ADDRESS, EMAIL , MOBILE  , ACCOUNT,PASSWORD)
//     VALUES ($_POST["uname"],$_POST["uaddress"], $_POST["uemail"], $_POST["umobile"], $_POST["uacnumber"], $_POST["upassword"]);
// EOF;
//     $ret = $db->query($sql);
//     echo "Registration Successful\n";
// }

$db->close();
?>
</body>
</html>