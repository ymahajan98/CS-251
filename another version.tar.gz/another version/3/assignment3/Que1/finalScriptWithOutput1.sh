#!/bin/bash

# This script for taking input from user by keyboard not at cmd
# USAGE run as "./finalScriptWithOutput.sh ./q1.py"    here q1.py is the script for question 1

sed '1d' final_answers_q1.txt > tmpfile
sed -e "s/[[:space:]]\+/ /g" tmpfile > input
rm -f tmpfile
i=1
while read sn number base output
do
	echo -e "\e[0;32m--------------------------------------------\e[0m"
	echo -e "\e[1;34mTestcase " $i ":\e[0m"
	echo -e "\t\e[1;33mInput:\e[0m\e[0;31m " $number $base "\e[0m"
	echo -ne "\t\e[1;33mOutput: \e[0m\e[0;31m"
	echo $number > tmp
	echo $base >> tmp
	python $1 < tmp
	echo -e "\t\e[1;33mExpected output: \e[0m\e[0;31m" $output
	echo -e "\e[0;32m--------------------------------------------\e[0m"
	#echo ""
	i=$(( $i + 1 ))
done < input
rm -f input
rm -f tmp
