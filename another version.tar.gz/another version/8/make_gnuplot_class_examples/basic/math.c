#include "common.h"
int do_math(void)
{
   return 0;
}
