/**/char*s="asdjij\"//";char*s="ada//w"; char *s="hik" //them
