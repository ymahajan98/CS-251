#!/bin/bash

comments=0
strings=0

solve() {
    for i in $1/* ; do
        if [[ ! -d "$i" ]]
        then
            if [[ "$i"=~'.*\.c$' ]]
            then 
                a=$( cat "$i" | sed -E 's#\\"##g' | awk -f ./qn1.awk)
                var1=`echo "$a" | cut --delimiter="," -f 1`
                var2=`echo "$a" | cut --delimiter="," -f 2`
                comments=$(( $comments + $var1 ))
                strings=$(( $strings + $var2 ))
                
            fi
        else
            solve $i
        fi
    done
}

directory=$1

solve $directory 
echo  $comments lines of comments
echo  $strings quoted strings
