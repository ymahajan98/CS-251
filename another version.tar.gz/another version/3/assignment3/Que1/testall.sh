#!/bin/sh
# use "./testall.sh final_input_case_q1.txt q1.py"
# change python2 to python3 for Python 3

# the whole loop reads $1 line by line
echo "OUTPUT:"
while read linea1
do
    # run $2 with the contents of the file that is in the line just read
    python2 $2 $linea1
done < $1