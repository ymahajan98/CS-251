// this is a single line comment
/*this is also a multi line comment */
/* This is anothe
  ne “comment”
considered as 4 lines
*/

#include <stdio.h>
int solution(void)
{
    char *s = "try combinations of strings and /*comments*/ too";
    return 0;
}
