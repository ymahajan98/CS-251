#!/usr/bin/python

import numpy as np
import matplotlib.pyplot as plt
import csv
import math

#NOTE:
# Currently 5 positions are getting plotted-
# 1. Train data, in terms of red points.
# 2. Initial calculated label value (using randomly generated w)
# 3. Using w_direct
# 4. During calculation of optimal w, everytime i%100 is true
# 5. Using final w.

rownum1 = 1

n_train = 10000
n_test = 10500
eta = 0.00000001

f = open('train.csv','r')  #change this location before finishing

x_train = np.empty(shape=(0,0))
y_train = np.empty(shape=(0,0))

csvreader = csv.reader(f)

for row in csvreader:
    if rownum1 == 1:
        rownum1 = 0
    else: 
        x_train = np.append(x_train,float(row[0]))
        y_train = np.append(y_train,float(row[1]))
        
# print (x_train)

# print (x_train.shape())
        
xtemp = x_train
x_train = np.ones((n_train,2))
x_train[:,1:] = xtemp.reshape((n_train,1))

# print (y_train[0])

ytemp = y_train
y_train = np.zeros((n_train,1))
y_train[:,0:] = ytemp.reshape((n_train,1))

# print (y_train[0])

# print (x_train)
# print (x_train[1:])

w = np.random.rand(2,1)
# print (w)

fig = plt.figure()

plt.plot(x_train[:,1],y_train, 'ro')
# plt.plot(x_train[:,1],np.dot(w.transpose(),x_train.transpose())[:,0])
plt.plot(x_train[:,1],np.dot(x_train,w),'b-')

plt.xlabel('feature')
plt.ylabel('label')

plt.title("Plot for linear regression")

# plt.show()

mat = np.dot(x_train.transpose(),x_train)
inv = np.linalg.inv(mat)

# y_train = y_train.reshape(n_train,1)

# print (np.shape(inv))
# print (np.shape(x_train))
# print (np.shape(y_train))
w_direct2 = np.dot(inv, x_train.transpose())
# print (w_direct2[0,0])
# print (y_train[0])
# print (x_train[0,1])
w_direct = np.dot(w_direct2,y_train)
# w_direct = np.dot(inv,x_train.transpose(),y_train)
plt.plot(x_train[:,1],np.dot(x_train,w_direct), 'b-')

# print (np.shape(w))
for i in range(0,n_train):
    xd = x_train[i].transpose()
    yd = y_train[i,0]
#     print (w)
    w = w - (eta*(np.dot(w.transpose(),xd)[0] - yd)*xd).reshape(2,1)
    
    if i % 100 == 0:
        plt.plot(x_train[:,1],np.dot(x_train,w))

plt.plot(x_train[:,1],np.dot(x_train,w))
# print (np.dot(x_train,w)[0])
plt.show()

f2 = open('test.csv','r')
csvreader2 = csv.reader(f2)

x_test = np.empty(shape=(0,0))
y_test = np.empty(shape=(0,0))
row_num1 = 1

for row in csvreader2:
    if row_num1 == 1:
        row_num1 = 0
    else: 
        x_test = np.append(x_test,float(row[0]))
        y_test = np.append(y_test,float(row[1]))
        
x2temp = x_test
x_test = np.ones((n_test,2))
x_test[:,1:] = x2temp.reshape((n_test,1))

y2temp = y_test
y_test = np.zeros((n_test,1))
y_test[:,0:] = y2temp.reshape((n_test,1))

y_pred1 = np.dot(x_test,w)

rms1 = math.sqrt(np.sum(np.square(y_pred1 - y_test),axis=0)/float(n_test))
print ("rms error between y_pred1 and y_test = %f" % rms1)

y_pred2 = np.dot(x_test,w_direct)

rms2 = math.sqrt(np.sum(np.square(y_pred2 - y_test),axis=0)/float(n_test))
print ("rms error between y_pred2 and y_test = %f" % rms2)