<!DOCTYPE html>
<html>
<head>
  <title>Form Validation</title>
  <script>
    function validate() {
      var name = document.forms["createUser"]["uname"].value;
      var address = document.forms["createUser"]["uaddress"].value;
      var email = document.forms["createUser"]["uemail"].value;
      var mobile = document.forms["createUser"]["umobile"].value;
      var account = document.forms["createUser"]["uacnumber"].value;
      var password = document.forms["createUser"]["upassword"].value;

      var regexName = /^[a-zA-Z ]*$/;
      var regexPassword = /^\w+$/;
      var regexEmail = /\b[a-zA-Z]+@[a-zA-Z0-9.-]+\.com\b/;

      if(name == "" || name.length > 20 || !regexName.test(name)) {
        alert("Invalid Name");
        return false;
      }
      if(address.length > 100 || address == "") {
        alert("Invalid Address");
        return false;
      }
      if(email == "" || !regexEmail.test(email)) {
        alert("Invalid Email");
        return false;
      }
      if(isNaN(mobile) || mobile.length != 10) {
        alert("Invalid Mobile Number")
        return false;
      }
      if(isNaN(account) || account.length != 5) {
        alert("Invalid Bank Account Number");
        return false;
      }
      if(password.length > 20 || password == "" || !regexPassword.test(password)) {
        alert("Invalid Password");
        return false;
      }
      
    }
  </script>

</head> 

<body>
  <div>
    <h1>Registration Page</h1>
     <form name="createUser" onsubmit="return validate()" method="post" action="checker.php">
      Name: <br/> <input type="text" name="uname"> <br/>
      Address: <br/> <input type="text" name="uaddress"> <br/>
      Email: <br/> <input type="text" name="uemail"> <br/>
      Mobile Number: <br/> <input type="text" name="umobile"> <br/>
      Bank Account Number: <br/> <input type="text" name="uacnumber"> <br/>
      Bank Password: <br/> <input type="password" name="upassword"> </br>
      <p id="result"> </p>

      <input type="submit" value="submit">
    </form>
    <br/>
    <br/>
    <a href="admin.php">Admin Login</a>
  </div>
</body>
</html>