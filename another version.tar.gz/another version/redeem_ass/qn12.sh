#!/bin/bash

file=$1
echo $file

filedepth=1
dirdepth=1
dir=0
f=0
filename="random"
dirname="random"

#`mkdir "answer"`
#`cd "answer"`

cnt=0
NN=172932131231

while IFS='' read -r line || [[ -n "$line"  ]]; do
    data=`echo $line`
    echo "cnt: $cnt, line: $data"
    cnt=$(( $cnt + 1  ))

    if [ "$dirname" == "findthename" ]; then
        dirname=`echo "$data" | grep -o -P '(?<=\<name\>).*(?=\</name\>)'`
        echo "dirname: $dirname"
        # get the dir name mkdir and cd
    elif [ "$filename" == "findthename" ]; then
        filename=`echo "$data" | grep -o -P '(?<=\<name\>).*(?=\</name\>)'`
        # store the value in filename
        echo "filename: $filename"
        filesize=$NN
        # to get filesize in next step
    elif [[ ( $filesize -eq $NN ) ]]; then
        filesize=`echo "$data" | grep -o -P '(?<=\<size\>).*(?=\</size\>)'`
        filesize=$(( $filesize + 0  )) #converting to int
        echo "filesize: $filesize"
    elif [ "$data" == "<dir>" ]; then
        dirname="findthename"
    elif [ "$data" == "</dir>" ]; then
        echo "cd ../"
        # move to parent directory
    elif [ "$data" == "<file>" ]; then
        filename="findthename"
    elif [ "$data" == "</file>" ]; then
        echo "yo"
    fi
done < "$file"
