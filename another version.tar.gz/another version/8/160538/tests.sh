#!/bin/sh
`rm -f report.log`

# bash script to generate the data for test file

params=`cat params.txt`
threads=`cat threads.txt`
iterations=100

# `chmod +x app`
prefix="Time taken ="
suffix="microsecs"

for param in $params
do
	for thread in $threads
	do
		cnt=0
		avg=0
		while [ $cnt -lt $iterations ] 
		do
			t=` $(echo ./app $param $thread) | sed -e "s/^$prefix//" -e "s/$suffix$//"`
			printf $param" " >> report.log
			printf $thread" " >> report.log
			echo $t >> report.log
			cnt=$(( $cnt + 1 ))
	    done
	done
done
