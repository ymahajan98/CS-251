#!/bin/bash 
# this first line tells system which program to use to run the file

echo "Hello World"
