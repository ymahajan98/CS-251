n_train = 10000;
n_test = 1000;

filename = 'train.csv';
train = csvread(filename);

train(1, :)