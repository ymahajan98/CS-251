#!/bin/bash

# pipes allow us to use input of 1 file as input to other

ls -l | grep "\.txt"
#output of ls -l is passed to grep which prints the result
# which tries to match the regex $\.txt$
