import numpy as np
import math
import matplotlib.pyplot as plt
from sklearn.metrics import mean_squared_error
from numpy import genfromtxt
with open('train.csv') as file:
    my_data = genfromtxt('train.csv', delimiter=',')
mydata=my_data[1:].transpose()
fig, ax = plt.subplots(nrows=6, ncols=7)
X_train=mydata[0]
Y_train=mydata[1]
ones=np.ones([len(X_train)])
x_dash=np.concatenate([X_train,ones]).reshape(2,len(X_train))
x_train=x_dash.transpose()
w=np.random.randn(1,2)
temp=np.matmul(w,x_dash).reshape(len(X_train))
plt.subplot(6,7,1)
plt.plot(Y_train,X_train,'ro')
plt.plot(temp,X_train)
w_direct1=np.linalg.inv(np.matmul(x_dash,x_train))
w_direct2=np.matmul(x_dash,Y_train)
w_direct=np.matmul(w_direct1,w_direct2)
temp=np.matmul(w_direct,x_dash).reshape(len(X_train))
plt.subplot(6,7,2)
plt.plot(Y_train,X_train,'ro')
plt.plot(temp,X_train)
k=3
batch_size=10
temp1=Y_train.transpose()-np.matmul(w,x_dash)
for i in range(1,3):
    for j in range(1,len(X_train)-batch_size):

        y_train_temp=Y_train[(j-1)*batch_size:j*batch_size]
        x_dash_temp=x_dash[:,(j-1)*batch_size:j*batch_size]
        x_train_temp=x_train[(j-1)*batch_size:j*batch_size,:]
        w=w+0.000000000744*np.matmul(y_train_temp.transpose()-np.matmul(w,x_dash_temp),x_train_temp)

        if (j%500==0):
            temp=np.matmul(w,x_dash).reshape(len(X_train))
            plt.subplot(6,7,k)
            plt.plot(Y_train,X_train,'ro')
            plt.plot(temp,X_train)
            k=k+1

temp=np.matmul(w,x_dash).reshape(len(X_train))
plt.subplot(6,7,k)
plt.plot(Y_train,X_train,'ro')
plt.plot(temp,X_train)
k=k+1
with open('train.csv') as file:
    my_data = genfromtxt('test.csv', delimiter=',')
mydata=my_data[1:].transpose()
X_test=mydata[0]
Y_test=mydata[1]
ones=np.ones([len(X_test)])
x_dash_test=np.concatenate([X_test,ones]).reshape(2,len(X_test))
y_pred1=np.matmul(w,x_dash_test).reshape(len(X_test))
y_pred2=np.matmul(w_direct,x_dash_test).reshape(len(X_test))
print((math.sqrt(np.square(y_pred1-Y_test).sum() / 10000)))
print(math.sqrt(np.square(y_pred2-Y_test).sum() / 10000))
print(w)
plt.show()
