import sys


arguments = sys.argv

if len(arguments) != 3:
    print "Invalid Input"
    sys.exit()


# stores the value corresponding to each char
numberMapping = {}
for i in range(10):
    numberMapping[chr(i+48)] = i
for i in range(26):
    numberMapping[chr(i+65)] = i+10
numberMapping['-'] = 0


# base check
flag = 1
base = 0

arguments[2] = arguments[2].strip()

for i in range(len(arguments[2])):
    if arguments[2][i] < '0' or arguments[2][i] > '9':
        flag = 0
        break
    base = base*10 + numberMapping[arguments[2][i]]

if flag == 0 or base < 2 or base > 36:
    print "Invalid Input"
    sys.exit()


# getting allowed char in number
allowed = []
for i in range(min(base,10)):
    allowed.append(chr(i+48))
flag = base - 10
if flag > 0:
    for i in range(flag):
        allowed.append(chr(i+65))


#number check
N = arguments[1].upper() #since we r working in upper case
N = N.strip()

if N == "-" or N == "." or N == "-.":
    print "Invalid Input"
    sys.exit()

flagneg = 0
flagdot = 0
flag = 1

for i in range(len(N)):
    if(N[i] == '.'):
        if(flagdot == 1):
            flag = 0
            break
        else:
            flagdot = 1
    elif (N[i] == '-'):
        if(flagneg == 1):
            flag = 0
            break
        elif(i != 0):
            flag = 0
            break
        else:
            flagneg = 1
    elif(N[i] not in allowed):
        flag = 0
        break

if flag == 0:
    print "Invalid Input"
    sys.exit()

left = ""
right = ""

if flagdot == 1:
    left, right = N.split(".")
else:
    left = N

number = 0
index = 0

for i in range(len(left)-1,-1,-1):
    number = number + numberMapping[left[i]]* (base ** index)
    index = index + 1
index = -1
for i in range(0,len(right)):
    number = number + numberMapping[right[i]] * ( base ** index )
    index = index - 1

if number > 999999999:
    print "Invalid Input"
    sys.exit()

if flagneg == 1:
    number = 0 - number
print number
