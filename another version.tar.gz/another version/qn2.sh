#!/usr/bin/env bash
#set -x

sentence='\b((?!=|\!|\?|\.).)+([^\d].)\b'
integers='\b(?<!\.)\b(-?[\d]+)(?!\.\d+)\b'

# conuter to keep track of directory levels
j=0

#Used as a separator
line="~~"

function recurse {
    for file in $1/*; do 
        if [[ ! -d "$file" ]]; then

            local_cnt1=$(grep -roP $sentence "$file" | wc -l)
            local_cnt2=$(grep -roP $integers "$file" | wc -l)

            echo "${line}"'(F)'"$file"'-'"$local_cnt1"'-'"$local_cnt2" | sed -E 's/(\~*)?(\(F\)).+\//\1\2/g'  | sed 's/~~/    /g'
            
            j=$(($j-1))

            line=${line%"~~"}
            
        else

            global_cnt1=$(grep -roP $sentence "$file" | wc -l)
            global_cnt2=$(grep -roP $integers "$file" | wc -l)

            echo "${line}"'(D)'"$file"'-'"$global_cnt1"'-'"$global_cnt2" | sed -E 's/(\~*)?(\(D\)).+\//\1\2/g' | sed 's/~~/    /g'

            j=$(($j+1))

            line=$line"~~"

            recurse "${file}"
        fi
            
    done
}

recurse $1

global_cnt1=$(grep -roP $sentence "$1" | wc -l)
global_cnt2=$(grep -roP $integers "$1" | wc -l)
echo '(D)'"$1"'-'"$global_cnt1"'-'"$global_cnt2"











