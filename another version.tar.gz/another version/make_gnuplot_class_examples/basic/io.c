#include "common.h"
int do_io(void)
{
   return 0;
}
