# 1)
num_sample <- 50000;
sz <- 500;
a <- rexp(num_sample, 0.2);

plot(seq(1,num_sample,1),sort(a),xlab="X",ylab="Y", main="scatter plot for samples")

# 2) partitioning to 500 vectors
y <- matrix(a, 100, sz)

# 3) calculating mean and sd
means <- c(1:sz);
standard_dev <- c(1:sz);
for(i in 1:sz) {
    curr = y[,i];
    means[i] = mean(curr);
    standard_dev[i] = sd(curr);
}

max_a <- 50;

# 3a) plotting CDF and PDF for first 5 vectors
for(i in 1: 5) {
    mat = y[,i];
    num_element <- 100;
    pdata <- rep(0,50);

    for(j in 1: num_element) {
        val <- round(mat[j],0);
        if(val <= 50) {
            pdata[val] = pdata[val] + 1/num_element;
        }
    }
    xcols <- c(0:49);
    st <- paste("Y",i," (PDF)");
    plot(xcols, pdata, "l", xlab = "X", ylab = "P(X)", main=st);

    cdata <- rep(0,50);
    cdata[1] = pdata[1];
    for(j in 2: 50)
        cdata[j] = cdata[j-1] + pdata[j];
    st <- paste("Y",i," (CDF)");
    plot(xcols, cdata, "o", col="blue", xlab = "X", ylab = "F(X)", main=st);   
}

# 3b) printing mean and SD for first 5 values
for(i in 1: 5) {
    st <- paste("Y_",i);
    cat(st," mean:= ",means[i], ", standard deviation:= ",standard_dev[i],"\n");
}

# 4a) frequency plot
tab <- table(round(means))
plot(tab, "h", xlab="Value", ylab="Frequency", main="Frequency of means");

# 4b) pdf and cdf plot
pdata = rep(0,10);
cdata = rep(0,10);

cdata[1] = pdata[1];

for(i in 1: 500) {
    val <- round(means[i], 0);
    pdata[val] = pdata[val] + 1/500;
}

xcols <- c(0:9);
plot(xcols, pdata, "l", xlab = "mean", ylab = "P(mean)", main="pdf of means");

for(i in 2: 10) {
    cdata[i] = cdata[i-1] + pdata[i];
}
plot(xcols, cdata, "o", col="blue", xlab = "mean", ylab = "F(mean)", main = "cdf of means");

# 5) mean and standard deviation of means

final_mean <- mean(means);
final_sd <- sd(means);

cat("mean of distribution sample mean: ",final_mean,"\n","standard deviation of sample means: ", final_sd, "\n");

# 6) absolute error
cat("Absolute error in mean",abs(final_mean - 5),"\n");
cat("Absolute error in standard deviation",abs(final_sd - 0.5), "\n");