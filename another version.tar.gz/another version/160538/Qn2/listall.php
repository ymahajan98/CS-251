<!DOCTYPE html>
<html>
<head>

</head>
<body>
<?php
    $db = new SQLite3('test.db');
  
?>
<?php
    $user = 
     $sql =<<<EOF
     SELECT * from ADMIN;
EOF;
     $ret = $db->query($sql);
     $flag = 0;
    while($row = $ret->fetchArray() ) {
    if($row['USERNAME'] == $_POST["username"] && $row['PASSWORD'] == $_POST["password"]) {
        $sql =<<<EOF
        SELECT * from REGISTERED;
EOF;
    echo "login successful";
     $ret = $db->query($sql);
     echo "<table style=\"width:100%\">
    <th>ID </th>
    <th> NAME</th>
    <th> ADDRESS</th>
    <th>MOBILE NUMBER  </th>
    <th> ACCOUNT</th>";
     while($row = $ret->fetchArray() ) {
        echo " <tr> <td>". $row['NAME'] ;
        echo " </td> <td> ". $row['EMAIL'] ;
        echo " </td> <td> ". $row['ADDRESS'];
        echo "</td> <td> ".$row['MOBILE'];
        echo " </td> <td> ".$row['ACCOUNT'];
        echo "</td></tr>";
     }
     echo "</table>";
    $flag = 1;
    }
}
    if($flag == 0) {
        echo "Invalid Username/Password";
    }
?>


</body>
</html>