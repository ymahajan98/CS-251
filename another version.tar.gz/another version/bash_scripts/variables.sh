#!/bin/bash

x=232323234242342424
# there should not be space between variable and = sign

echo $x

echo $(ls)
#this will execute the command ls other way is to use `ls`

#to create local variable use the keywork local

function :
