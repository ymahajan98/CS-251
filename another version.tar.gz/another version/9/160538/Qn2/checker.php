<!DOCTYPE html>
<html>
<head>

</head>
<body>
<?php
   class MyDB extends SQLite3 {
      function __construct() {
         $this->open('maindb.db');
      }
   }
   
   $db = new MyDB();
   $sql =<<<EOF
   SELECT * from RREGISTERED;
EOF;
$flag1 = 0;
$ret = $db->query($sql);
while($row = $ret->fetchArray(SQLITE3_ASSOC) ) {
    if($row['EMAIL'] == $_POST["uemail"]) {
        echo "This email is already registered\n";
        $flag1 = 1;
    }
}

$sql =<<<EOF
   SELECT * from BALANCE;
EOF;
$ret = $db->query($sql);
while($row = $ret->fetchArray(SQLITE3_ASSOC) ) {
    if($row['ACCOUNT'] == $_POST["uacnumber"] && $row['PASSWORD'] != $_POST["upassword"]) {
        echo "Invalid Account/Password\n";
        $flag1 = 1;
    }
    if($row['ACCOUNT'] == $_POST["uacnumber"] && $row['PASSWORD'] == $_POST["upassword"] && $row['AMOUNT'] < 1000) {
        echo "Insufficient Balance\n";
        $flag1 = 1;
    }
    if($row['ACCOUNT'] == $_POST["uacnumber"] && $row['PASSWORD'] == $_POST["upassword"] && $row['AMOUNT'] >= 1000 && $flag1 == 0) {
        $new = $row['AMOUNT'] - 1000;
        $sql =<<<EOF
            DELETE from BALANCE where ACCOUNT=$row['ACCOUNT'];
EOF;
        $ret = $db->query($sql);
        $sql =<<<EOF
        INSERT INTO BALANCE (ACCOUNT,PASSWORD,AMOUNT)
      VALUES ($row['ACCOUNT'], $row['PASSWORD'], $new );
EOF;
        $ret = $db->query($sql);
    }
}

if($flag1 == 0) {
    $sql =<<<EOF
    INSERT INTO BALANCE (NAME, ADDRESS, EMAIL , MOBILE  , ACCOUNT,PASSWORD)
    VALUES ($_POST["uname"],$_POST["uaddress"], $_POST["uemail"], $_POST["umobile"], $_POST["uacnumber"], $_POST["upassword"]);
EOF;
    $ret = $db->query($sql);
    echo "Registration Successful\n";
}

$db->close();
?>
</body>
</html>