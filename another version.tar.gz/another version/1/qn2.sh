#!/bin/bash
#set -x

#regex based on look ahead and behind
regex_line='(\!|\?)|((?<!\d)\.(?!\d))|((?<=\d)\.(?!\d))|((?<!\d)\.(?=\d))'
regex_int='(?<![0-9]\.)\b-?[0-9]+\b(?!\.[0-9]+)'

indent="^^^^" #stores the current indentation
solve() {

    for i in  $1/* ; do
        if [[ ! -d "$i" ]]
        then
            lines=$(grep -roP "$regex_line" "$i" 2>/dev/null | wc -l) # recursive grup
            ints=$(grep -roP "$regex_int" "$i" 2>/dev/null | wc -l)
            echo "${indent}"'(F)'"$i"'-'"$lines"'-'"$ints" | sed -E 's/(\^*)?(\(F\)).+\//\1\2/g'  | sed 's/\^/ /g'
            # sed to replace indentation and previous directory address

        else
            lines=$(grep -roP "$regex_line" "$i" 2>/dev/null | wc -l)
            ints=$(grep -roP "$regex_int" "$i" 2>/dev/null | wc -l)
            echo "${indent}"'(D)'"$i"'-'"$lines"'-'"$ints" | sed -E 's/(\^*)?(\(D\)).+\//\1\2/g'  | sed 's/\^/ /g'
            indent+="^^^^"
            solve $i
            indent=${indent%"^^^^"}
        fi
    done
}

directory=$1
indentation=""
name=$1


solve $directory

lines=$(grep -roP "$regex_line" "$directory" | wc -l)
ints=$(grep -roP "$regex_int" "$directory" | wc -l)

printf "(D) $directory-$lines-$ints\n"

#discussed the problem with bhavishya
