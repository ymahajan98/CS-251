graphics_toolkit('gnuplot');
# 1
filename = 'train.csv';
train = csvread(filename);

X_train = train(:,1);
Y_train = train(:,2);
n_train = size(X_train)(1);

X_train = [ones(n_train, 1), X_train];

# 2
w = rand(2,1);

# 3
hold on;
scatter(train(:,1), train(:, 2));
plot(train(:,1), w'* X_train');
scatter(train(:,1), w'* X_train');

xlabel("X");
ylabel("Y");
title("using W");

print -dpdf "step3.pdf";
close;

# 4
w_direct = (inv(X_train' * X_train) * X_train') * Y_train;
hold on;
plot(train(:,1), train(:, 2));
plot(train(:,1), w_direct' * X_train');

xlabel("X");
ylabel("Y");
title("using W direct");

print -dpdf "step4.pdf";
close;

# 5
eta = 0.00000001;
for i = 1:2,
    for j = 1: n_train,
        xx = X_train(j,:);
        yy = Y_train(j,:);

        w = w - ( eta *(w' * xx' - yy) * xx');
        if(mod(j,100) == 0),
            # hold on;
            # plot(train(:,1), train(:, 2));
            # 
            # plot(train(:,1), w'* X_train');
            # xlabel("X");
            # ylabel("Y");
            # print -dpdf -append "step5.pdf";
            # close;
            j
        end,
    end,
end,

# 6

hold on;
scatter(train(:,1), train(:, 2));
plot(train(:,1), w'* X_train');
scatter(train(:,1), w'* X_train');

xlabel("X");
ylabel("Y");
title("using udpated W");

print -dpdf "step6.pdf";
close;

# 7
filename = "test.csv";
test = csvread(filename);

X_test = test(:,1);
Y_test = test(:,2);
n_test = size(X_test)(1);

X_test = [ones(n_test, 1), X_test];
y_pred1 = X_test * w;
y_pred2 = X_test * w_direct;
rms1 = 0;
rms2 = 0;

for i = 1:n_test,
    rms1 = rms1 + (y_pred1(i) - Y_test(i)).^2;
    rms2 = rms2 + (y_pred2(i) - Y_test(i)).^2;
end,
rms1 = rms1 / n_test;
rms2 = rms2 / n_test;
rms1 = sqrt(rms1);
rms2 = sqrt(rms2);

rms1
rms2