<!DOCTYPE html>
<html>
<head>

</head>
<body>
<?php
    class MyDB extends SQLite3 {
        function __construct() {
           $this->open('maindb.db');
        }
     }
     
     $db = new MyDB();
     $sql =<<<EOF
     SELECT * from ADMIN;
EOF;
     $ret = $db->query($sql);
    while($row = $ret->fetchArray(SQLITE3_ASSOC) ) {
    if($row['USERNAME'] == $_POST["username"] && $row['password'] != $_POST["password"]) {
        echo "Invalid Username/ Password\n";
    }
    if($row['USERNAME'] == $_POST["username"] && $row['password'] == $_POST["password"]) {
        $sql =<<<EOF
        SELECT * from REGISTERED;
EOF;
     $ret = $db->query($sql);
     while($row = $ret->fetchArray(SQLITE3_ASSOC) ) {
        echo "ID = ". $row['NAME'] . "\n";
        echo "NAME = ". $row['EMAIL'] ."\n";
        echo "ADDRESS = ". $row['ADDRESS'] ."\n";
        echo "SALARY = ".$row['MOBILE'] ."\n\n";
        echo "ACCOUNT = ".$row['ACCOUNT'] ."\n\n";
     }
    }
}
?>


</body>
</html>