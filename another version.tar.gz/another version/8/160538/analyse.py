# python script to analyse the test.log file for each thread
from __future__ import division

file1 = open("report.log","r")
file1 = file1.read()

tm = map(int, file1.split())

# reading all params
paramfile = open("params.txt","r")
paramfile = paramfile.read()
paramfile = map(int, paramfile.split())

# reading all threads
threadfile = open("threads.txt","r")
threadfile = threadfile.read()
threadfile = map(int, threadfile.split())

reportall = {}
avgall = {}
bar_data = {}
bar_data_var = {}

# init
for i in paramfile:
	bar_data[i] = ""
	bar_data_var[i] = ""

for i in threadfile:
	reportall[i] = ""
	avgall[i] = ""

it = 2
for param in paramfile:
	bar_data[param] = str(param) + " "
	for thread in threadfile:
		avg = 0
		for i in range(100):
			avg = avg + tm[it]
			reportall[thread] = reportall[thread] + str(param) + " " + str(tm[it]) + "\n"
			it = it + 3
		avg = avg / 100
		avgall[thread] = avgall[thread] + str(param) + " " + str(avg) + "\n"
		if thread == 1:
			avg1 = avg
		ans = avg1/avg

		bar_data[param] = bar_data[param] + str(ans) + " "

		it = it - 300
		xx = 0
		for i in range(100):
			xx = (tm[it] - avg)**2
			it = it+3
		xx = xx/100
		bar_data_var[param] = bar_data_var[param] + str(xx) + " "

name = "report"
suffix = ".rtf"
for i in threadfile:
	f1 = open(name+ str(i) +suffix, "w")
	f1.write(reportall[i])
	f1.close()

name = "avg"
for i in threadfile:
	f1 = open(name + str(i) + suffix, "w")
	f1.write(avgall[i])
	f1.close()



f1 = open("bar_graph.rtf", "w")
for i in paramfile:
	bar_data[i] = bar_data[i] + bar_data_var[i] + "\n"
	f1.write(bar_data[i])
f1.close()