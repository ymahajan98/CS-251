#!/bin/bash
for i in `ls`; do
       echo item: $i
done #done indicates scope of $i finished

ans=0; counter=10
while [ $counter -gt 0 ]; do
    ans=$(( ans + counter )) #for doing airthematic operations
    #we need to use $(( here ))
    echo "ans:" $ans "counter:" $counter
    counter=$(( ( counter - 1 ) / 3 )) #number of airthematic
    #operations can be done here just use brackets
done

