<!DOCTYPE html>
<html>
<head>
  <title>Admin Login</title>
</head>

<body>
    <h1> Admin Login</h1>
    <div>
        <form method="post" action="listall.php">
            Username: <br/>
            <input type="text" name="username"> <br/>
            Password: <br/>
            <input type="text" name="password"> <br/>

            <input type="submit" value="submit">
        </form>
    </div>    
</body>

</html>