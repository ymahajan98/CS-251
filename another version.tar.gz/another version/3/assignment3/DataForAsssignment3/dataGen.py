import random 
import numpy as np
import sys
import matplotlib.pyplot as plt
w=11.256
b=6.564
x=[]

 
csv = open("train.csv", "w") 
for i in range(10000):   
   x.append(random.uniform(0, 1000))
x.sort()


print(x)
print(len(x))
y=[]
row="X_train,Y_train\n"
csv.write(row)

ll=[]
for i in range(len(x)):
    y.append(np.dot(w,x[i])+b+random.uniform(0, 100))
    ll.append(str(x[i])+","+str(y[i]))
	
random.shuffle(ll)    	
print(y)

for i in range(len(x)):
    csv.write(ll[i]+"\n")


plt.plot(x, y,linewidth=1)
plt.show()







csv1 = open("test.csv", "w") 
for i in range(500):   
   x.append(random.uniform(0, 1000))
x.sort()


print(x)
print(len(x))
y=[]
row="X_test,Y_test\n"
csv1.write(row)

ll=[]
for i in range(len(x)):
    y.append(np.dot(w,x[i])+b+random.uniform(-5, 5))
    ll.append(str(x[i])+","+str(y[i]))
	
random.shuffle(ll)    	
print(y)

for i in range(len(x)):
    csv1.write(ll[i]+"\n")














































