#include <stdio.h>

/*
 *
 *
 *
 * // " "
 * sakdo
 */

//
int main()
{
  printf("Hello\"World!);return 0;}");//What's Up
  char *s = "ksajdk/*";
  char *s = "koqw//odas/* */ ";
  return 0;
}
  
