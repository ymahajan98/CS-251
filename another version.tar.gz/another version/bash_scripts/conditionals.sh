#!/bin/bash

if [ "yo"="yo" ]; then
	echo "raman is god"
fi
#there should be not a space between if and [

if [ 1 -lt 2 ]; then
    echo expression evaluated as true.
else
	echo expression evaluated as false.
fi
